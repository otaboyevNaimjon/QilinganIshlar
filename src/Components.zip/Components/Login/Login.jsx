import React, { useState } from 'react'
import "./Login_Page.css"
import { useNavigate } from 'react-router-dom'

export default function Login_Page() {
  const [active, setactive] = useState(true)
  let data = [
    {
      name: "Naimjon",
      password: 7714001,
      color: "white"
    },
    {
      name: "Abdullo",
      password: 4315596,
      color: "white"
    },
    {
      name: "Shoxhur",
      password: 123321123321,
      color: "white"
    },
    {
      name: "Umarbek",
      password: 3009,
      color: "white"
    }
  ]
  const navigate = useNavigate()
  const [name, setname] = useState(null)
  const [parol, setparol] = useState(null)
  function checkpassword(val) {

    data.map((arr, index) => {
      if (arr.name == name && arr.password == parol) {
        navigate('/navbar')
        console.log("parol togri");
        setactive(true)
      }
      else {
        setactive(false)
      }
    })
  }

  return (
    <div className='Registration'>
      <div className="leftside">

      </div>
      <div className="Registr">
        <div className="Registration_form">
          <h1 className='wel'>Welcome!</h1>
          <input style={active ? { color: "blue" } : { color: "red" }} onInput={(val) => {
            setname(val.target.value); if (name.length === 0 || parol.length === 0) {
              setactive(true)
            }
          }} className='username' type="text" placeholder='username... ' />
          <input style={active ? { color: "blue" } : { color: "red" }} onInput={(val) => {
            setparol(val.target.value);
            if (name.length === 0 || parol.length === 0) {
              setactive(true)
            }
          }} className='password' type="password" placeholder='parol...' />
          <button className='Kirish' onClick={(val) => { checkpassword(val) }}>Kirish</button>
        </div>
      </div>
    </div>
  )
}
//
// 
